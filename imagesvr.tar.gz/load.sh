#!bin/bash
nohup ./bin/imagesvr.201708291835 >./logs/imagesvr.201708291835.log 2>./logs/error.log &
