#!bin/bash
nohup ./bin/imagesvr.201708291843 >./logs/imagesvr.201708291843.log 2>./logs/error.log &
