#!bin/bash
nohup ./bin/imagesvr.201708311525 >./logs/imagesvr.201708311525.log 2>./logs/error.log &
