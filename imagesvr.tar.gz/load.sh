#!bin/bash
nohup ./bin/imagesvr.201708291732 >./logs/imagesvr.201708291732.log 2>./logs/error.log &
