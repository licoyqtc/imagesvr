#!bin/bash
nohup ./bin/imagesvr.201709141739 >./logs/imagesvr.201709141739.log 2>./logs/error.log &
