#!bin/bash
nohup ./bin/imagesvr.201708291631 >./logs/imagesvr.201708291631.log 2>./logs/error.log &
