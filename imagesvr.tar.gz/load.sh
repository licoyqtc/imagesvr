#!bin/bash
nohup ./bin/imagesvr.201709131606 >./logs/imagesvr.201709131606.log 2>./logs/error.log &
