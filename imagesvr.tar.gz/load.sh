#!bin/bash
nohup ./bin/imagesvr.201708291739 >./logs/imagesvr.201708291739.log 2>./logs/error.log &
