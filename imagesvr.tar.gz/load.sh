#!bin/bash
nohup ./bin/imagesvr.201708301127 >./logs/imagesvr.201708301127.log 2>./logs/error.log &
