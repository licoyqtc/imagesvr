#!bin/bash
nohup ./bin/imagesvr.201708291703 >./logs/imagesvr.201708291703.log 2>./logs/error.log &
