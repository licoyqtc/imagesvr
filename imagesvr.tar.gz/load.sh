#!bin/bash
nohup ./bin/imagesvr.201708311513 >./logs/imagesvr.201708311513.log 2>./logs/error.log &
