#!bin/bash
nohup ./bin/imagesvr.201709061855 >./logs/imagesvr.201709061855.log 2>./logs/error.log &
