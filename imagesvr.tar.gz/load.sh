#!bin/bash
nohup ./bin/imagesvr.201708301151 >./logs/imagesvr.201708301151.log 2>./logs/error.log &
