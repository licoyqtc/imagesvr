#!bin/bash
nohup ./bin/imagesvr.201709071000 >./logs/imagesvr.201709071000.log 2>./logs/error.log &
