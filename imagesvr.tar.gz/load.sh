#!bin/bash
nohup ./bin/imagesvr.201709151141 >./logs/imagesvr.201709151141.log 2>./logs/error.log &
