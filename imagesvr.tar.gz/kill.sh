#!bin/bash
pid=$(ps -ef | grep imagesvr | grep -v grep | awk '{print $2}')
count=$(ps -ef | grep imagesvr | grep -v grep | wc -l)
if [ $count -ne 0 ];then kill $pid
fi
echo "count:"$count
